package sample02;


public class HelloSpring {
	
	public static void main(String[] args) {
		MessageBean messageBean = new MessageBeanKo();
				
		messageBean.sayHello("Spring");
	}
}