package sample02;

public class MessageBeanKo implements MessageBean {

	@Override
	public void sayHello(String name) {
		// TODO Auto-generated method stub
		
	}
	

}
